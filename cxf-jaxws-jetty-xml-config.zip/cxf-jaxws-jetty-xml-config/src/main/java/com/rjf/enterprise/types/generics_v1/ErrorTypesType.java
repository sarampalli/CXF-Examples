
package com.rjf.enterprise.types.generics_v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ErrorTypesType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ErrorTypesType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="AvailabilityException"/>
 *     &lt;enumeration value="LogicalException"/>
 *     &lt;enumeration value="SecurityException"/>
 *     &lt;enumeration value="ValidationException"/>
 *     &lt;enumeration value="UndeterminedException"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ErrorTypesType")
@XmlEnum
public enum ErrorTypesType {

    @XmlEnumValue("AvailabilityException")
    AVAILABILITY_EXCEPTION("AvailabilityException"),
    @XmlEnumValue("LogicalException")
    LOGICAL_EXCEPTION("LogicalException"),
    @XmlEnumValue("SecurityException")
    SECURITY_EXCEPTION("SecurityException"),
    @XmlEnumValue("ValidationException")
    VALIDATION_EXCEPTION("ValidationException"),
    @XmlEnumValue("UndeterminedException")
    UNDETERMINED_EXCEPTION("UndeterminedException");
    private final String value;

    ErrorTypesType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ErrorTypesType fromValue(String v) {
        for (ErrorTypesType c: ErrorTypesType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
