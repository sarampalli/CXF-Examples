@javax.xml.bind.annotation.XmlSchema(namespace = "http://enterprise.rjf.com/Types/Generics-v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.rjf.enterprise.types.generics_v1;
