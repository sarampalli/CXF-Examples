
package com.rjf.enterprise.types.generics_v1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ServiceContextType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceContextType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ServiceConsumerID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RequestID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ServiceMsgGUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Timestamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="ContextData" type="{http://enterprise.rjf.com/Types/Generics-v1}ContextDataType" maxOccurs="10" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceContextType", propOrder = {
    "serviceConsumerID",
    "requestID",
    "serviceMsgGUID",
    "timestamp",
    "contextData"
})
public class ServiceContextType {

    @XmlElement(name = "ServiceConsumerID", required = true)
    protected String serviceConsumerID;
    @XmlElement(name = "RequestID")
    protected String requestID;
    @XmlElement(name = "ServiceMsgGUID")
    protected String serviceMsgGUID;
    @XmlElement(name = "Timestamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timestamp;
    @XmlElement(name = "ContextData")
    protected List<ContextDataType> contextData;

    /**
     * Gets the value of the serviceConsumerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceConsumerID() {
        return serviceConsumerID;
    }

    /**
     * Sets the value of the serviceConsumerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceConsumerID(String value) {
        this.serviceConsumerID = value;
    }

    /**
     * Gets the value of the requestID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Sets the value of the requestID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestID(String value) {
        this.requestID = value;
    }

    /**
     * Gets the value of the serviceMsgGUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMsgGUID() {
        return serviceMsgGUID;
    }

    /**
     * Sets the value of the serviceMsgGUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMsgGUID(String value) {
        this.serviceMsgGUID = value;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTimestamp(XMLGregorianCalendar value) {
        this.timestamp = value;
    }

    /**
     * Gets the value of the contextData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contextData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContextData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContextDataType }
     * 
     * 
     */
    public List<ContextDataType> getContextData() {
        if (contextData == null) {
            contextData = new ArrayList<ContextDataType>();
        }
        return this.contextData;
    }

}
