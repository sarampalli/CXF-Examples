
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3.PeriodicPaymentProfileType;


/**
 * <p>Java class for UpdatePeriodicPaymentProfileRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdatePeriodicPaymentProfileRequestType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}PeriodicPaymentProfileType">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdatePeriodicPaymentProfileRequestType")
public class UpdatePeriodicPaymentProfileRequestType
    extends PeriodicPaymentProfileType
{


}
