
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddressTypeEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AddressTypeEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EmailAddress"/>
 *     &lt;enumeration value="Legal1099Address"/>
 *     &lt;enumeration value="PrimaryMailingAddress"/>
 *     &lt;enumeration value="DuplicateConfirmAddress"/>
 *     &lt;enumeration value="ConfirmPrimaryAddress"/>
 *     &lt;enumeration value="PhysicalAddress"/>
 *     &lt;enumeration value="StatementPrimaryAddress"/>
 *     &lt;enumeration value="PrimaryRegistrationOfAccount"/>
 *     &lt;enumeration value="SeasonalAddress"/>
 *     &lt;enumeration value="WebAddress"/>
 *     &lt;enumeration value="PrimaryClassWRecord20"/>
 *     &lt;enumeration value="Other"/>
 *     &lt;enumeration value="Unknown"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AddressTypeEnum")
@XmlEnum
public enum AddressTypeEnum {

    @XmlEnumValue("EmailAddress")
    EMAIL_ADDRESS("EmailAddress"),
    @XmlEnumValue("Legal1099Address")
    LEGAL_1099_ADDRESS("Legal1099Address"),
    @XmlEnumValue("PrimaryMailingAddress")
    PRIMARY_MAILING_ADDRESS("PrimaryMailingAddress"),
    @XmlEnumValue("DuplicateConfirmAddress")
    DUPLICATE_CONFIRM_ADDRESS("DuplicateConfirmAddress"),
    @XmlEnumValue("ConfirmPrimaryAddress")
    CONFIRM_PRIMARY_ADDRESS("ConfirmPrimaryAddress"),
    @XmlEnumValue("PhysicalAddress")
    PHYSICAL_ADDRESS("PhysicalAddress"),
    @XmlEnumValue("StatementPrimaryAddress")
    STATEMENT_PRIMARY_ADDRESS("StatementPrimaryAddress"),
    @XmlEnumValue("PrimaryRegistrationOfAccount")
    PRIMARY_REGISTRATION_OF_ACCOUNT("PrimaryRegistrationOfAccount"),
    @XmlEnumValue("SeasonalAddress")
    SEASONAL_ADDRESS("SeasonalAddress"),
    @XmlEnumValue("WebAddress")
    WEB_ADDRESS("WebAddress"),
    @XmlEnumValue("PrimaryClassWRecord20")
    PRIMARY_CLASS_W_RECORD_20("PrimaryClassWRecord20"),
    @XmlEnumValue("Other")
    OTHER("Other"),
    @XmlEnumValue("Unknown")
    UNKNOWN("Unknown");
    private final String value;

    AddressTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static AddressTypeEnum fromValue(String v) {
        for (AddressTypeEnum c: AddressTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
