
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3.CreatePeriodicDraftingProfileRequestType;
import com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3.UpdatePeriodicDraftingProfileRequestType;
import com.rjf.moneymovement.profile.schema.profilecommon_v3.FinancialInstitutionBaseType;
import com.rjf.moneymovement.profile.schema.profilecommon_v3.ProfileStatusType;


/**
 * <p>Java class for PeriodicDraftingProfileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicDraftingProfileType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}PeriodicProfileBaseType">
 *       &lt;sequence>
 *         &lt;element name="FinancialInstitution" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}FinancialInstitutionBaseType" minOccurs="0"/>
 *         &lt;element name="InvestmentPaymentAmount" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MoneyAmountType" minOccurs="0"/>
 *         &lt;element name="PeriodicDraftingProfileStatus" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileStatusType"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicDraftingProfileType", propOrder = {
    "financialInstitution",
    "investmentPaymentAmount",
    "periodicDraftingProfileStatus"
})
@XmlSeeAlso({
    CreatePeriodicDraftingProfileRequestType.class,
    UpdatePeriodicDraftingProfileRequestType.class
})
public class PeriodicDraftingProfileType
    extends PeriodicProfileBaseType
{

    @XmlElement(name = "FinancialInstitution")
    protected FinancialInstitutionBaseType financialInstitution;
    @XmlElement(name = "InvestmentPaymentAmount")
    protected BigDecimal investmentPaymentAmount;
    @XmlElement(name = "PeriodicDraftingProfileStatus", required = true)
    protected ProfileStatusType periodicDraftingProfileStatus;

    /**
     * Gets the value of the financialInstitution property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialInstitutionBaseType }
     *     
     */
    public FinancialInstitutionBaseType getFinancialInstitution() {
        return financialInstitution;
    }

    /**
     * Sets the value of the financialInstitution property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialInstitutionBaseType }
     *     
     */
    public void setFinancialInstitution(FinancialInstitutionBaseType value) {
        this.financialInstitution = value;
    }

    /**
     * Gets the value of the investmentPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getInvestmentPaymentAmount() {
        return investmentPaymentAmount;
    }

    /**
     * Sets the value of the investmentPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setInvestmentPaymentAmount(BigDecimal value) {
        this.investmentPaymentAmount = value;
    }

    /**
     * Gets the value of the periodicDraftingProfileStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ProfileStatusType }
     *     
     */
    public ProfileStatusType getPeriodicDraftingProfileStatus() {
        return periodicDraftingProfileStatus;
    }

    /**
     * Sets the value of the periodicDraftingProfileStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProfileStatusType }
     *     
     */
    public void setPeriodicDraftingProfileStatus(ProfileStatusType value) {
        this.periodicDraftingProfileStatus = value;
    }

}
