
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.rjf.moneymovement.profile.schema.profilecommon_v3 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.rjf.moneymovement.profile.schema.profilecommon_v3
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FinancialInstitutionType }
     * 
     */
    public FinancialInstitutionType createFinancialInstitutionType() {
        return new FinancialInstitutionType();
    }

    /**
     * Create an instance of {@link MonthlyFrequencyType }
     * 
     */
    public MonthlyFrequencyType createMonthlyFrequencyType() {
        return new MonthlyFrequencyType();
    }

    /**
     * Create an instance of {@link AnnualFrequencyType }
     * 
     */
    public AnnualFrequencyType createAnnualFrequencyType() {
        return new AnnualFrequencyType();
    }

    /**
     * Create an instance of {@link SemiMonthlyFrequencyType }
     * 
     */
    public SemiMonthlyFrequencyType createSemiMonthlyFrequencyType() {
        return new SemiMonthlyFrequencyType();
    }

    /**
     * Create an instance of {@link PaymentFrequencyType }
     * 
     */
    public PaymentFrequencyType createPaymentFrequencyType() {
        return new PaymentFrequencyType();
    }

    /**
     * Create an instance of {@link QuarterlyFrequencyType }
     * 
     */
    public QuarterlyFrequencyType createQuarterlyFrequencyType() {
        return new QuarterlyFrequencyType();
    }

    /**
     * Create an instance of {@link SemiAnnualFrequencyType }
     * 
     */
    public SemiAnnualFrequencyType createSemiAnnualFrequencyType() {
        return new SemiAnnualFrequencyType();
    }

    /**
     * Create an instance of {@link WeeklyFrequencyType }
     * 
     */
    public WeeklyFrequencyType createWeeklyFrequencyType() {
        return new WeeklyFrequencyType();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link ScheduledIncomeOptionsType }
     * 
     */
    public ScheduledIncomeOptionsType createScheduledIncomeOptionsType() {
        return new ScheduledIncomeOptionsType();
    }

    /**
     * Create an instance of {@link FinancialInstitutionBaseType }
     * 
     */
    public FinancialInstitutionBaseType createFinancialInstitutionBaseType() {
        return new FinancialInstitutionBaseType();
    }

    /**
     * Create an instance of {@link UpdatedByType }
     * 
     */
    public UpdatedByType createUpdatedByType() {
        return new UpdatedByType();
    }

}
