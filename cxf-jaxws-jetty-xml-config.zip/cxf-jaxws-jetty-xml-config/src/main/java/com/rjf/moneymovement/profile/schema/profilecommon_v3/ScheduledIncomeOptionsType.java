
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ScheduledIncomeOptionsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ScheduledIncomeOptionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PaymentFrequency" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}PaymentFrequencyType" minOccurs="0"/>
 *         &lt;element name="PaymentPeriodEndDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="NextEffectivePaymentDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ScheduledIncomeOptionsType", propOrder = {
    "paymentFrequency",
    "paymentPeriodEndDate",
    "nextEffectivePaymentDate"
})
public class ScheduledIncomeOptionsType {

    @XmlElement(name = "PaymentFrequency")
    protected PaymentFrequencyType paymentFrequency;
    @XmlElement(name = "PaymentPeriodEndDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar paymentPeriodEndDate;
    @XmlElement(name = "NextEffectivePaymentDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar nextEffectivePaymentDate;

    /**
     * Gets the value of the paymentFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentFrequencyType }
     *     
     */
    public PaymentFrequencyType getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Sets the value of the paymentFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentFrequencyType }
     *     
     */
    public void setPaymentFrequency(PaymentFrequencyType value) {
        this.paymentFrequency = value;
    }

    /**
     * Gets the value of the paymentPeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPaymentPeriodEndDate() {
        return paymentPeriodEndDate;
    }

    /**
     * Sets the value of the paymentPeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPaymentPeriodEndDate(XMLGregorianCalendar value) {
        this.paymentPeriodEndDate = value;
    }

    /**
     * Gets the value of the nextEffectivePaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getNextEffectivePaymentDate() {
        return nextEffectivePaymentDate;
    }

    /**
     * Sets the value of the nextEffectivePaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setNextEffectivePaymentDate(XMLGregorianCalendar value) {
        this.nextEffectivePaymentDate = value;
    }

}
