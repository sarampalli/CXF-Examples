
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.rjf.moneymovement.profile.schema.profilecommon_v3.ScheduledIncomeOptionsType;


/**
 * <p>Java class for PeriodicProfileBaseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicProfileBaseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}RJAccountNumberType"/>
 *         &lt;element name="AccountName" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}AccountNameType" minOccurs="0"/>
 *         &lt;element name="PeriodicProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType" minOccurs="0"/>
 *         &lt;element name="ACHProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType" minOccurs="0"/>
 *         &lt;element name="ScheduledIncomeOptions" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ScheduledIncomeOptionsType"/>
 *         &lt;element name="TransactionTrailer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicProfileBaseType", propOrder = {
    "accountNumber",
    "accountName",
    "periodicProfileNumber",
    "achProfileNumber",
    "scheduledIncomeOptions",
    "transactionTrailer",
    "userName"
})
@XmlSeeAlso({
    PeriodicPaymentProfileType.class,
    PeriodicDraftingProfileType.class
})
public abstract class PeriodicProfileBaseType {

    @XmlElement(name = "AccountNumber", required = true)
    protected String accountNumber;
    @XmlElement(name = "AccountName")
    protected String accountName;
    @XmlElement(name = "PeriodicProfileNumber")
    protected String periodicProfileNumber;
    @XmlElement(name = "ACHProfileNumber")
    protected String achProfileNumber;
    @XmlElement(name = "ScheduledIncomeOptions", required = true)
    protected ScheduledIncomeOptionsType scheduledIncomeOptions;
    @XmlElement(name = "TransactionTrailer")
    protected String transactionTrailer;
    @XmlElement(name = "UserName", required = true)
    protected String userName;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountName(String value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the periodicProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicProfileNumber() {
        return periodicProfileNumber;
    }

    /**
     * Sets the value of the periodicProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicProfileNumber(String value) {
        this.periodicProfileNumber = value;
    }

    /**
     * Gets the value of the achProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACHProfileNumber() {
        return achProfileNumber;
    }

    /**
     * Sets the value of the achProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACHProfileNumber(String value) {
        this.achProfileNumber = value;
    }

    /**
     * Gets the value of the scheduledIncomeOptions property.
     * 
     * @return
     *     possible object is
     *     {@link ScheduledIncomeOptionsType }
     *     
     */
    public ScheduledIncomeOptionsType getScheduledIncomeOptions() {
        return scheduledIncomeOptions;
    }

    /**
     * Sets the value of the scheduledIncomeOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScheduledIncomeOptionsType }
     *     
     */
    public void setScheduledIncomeOptions(ScheduledIncomeOptionsType value) {
        this.scheduledIncomeOptions = value;
    }

    /**
     * Gets the value of the transactionTrailer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionTrailer() {
        return transactionTrailer;
    }

    /**
     * Sets the value of the transactionTrailer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionTrailer(String value) {
        this.transactionTrailer = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

}
