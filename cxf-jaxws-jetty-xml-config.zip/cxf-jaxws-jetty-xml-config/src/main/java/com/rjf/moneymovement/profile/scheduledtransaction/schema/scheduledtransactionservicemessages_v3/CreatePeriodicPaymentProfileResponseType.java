
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CreatePeriodicPaymentProfileResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreatePeriodicPaymentProfileResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}RJAccountNumberType"/>
 *         &lt;element name="ACHProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType" minOccurs="0"/>
 *         &lt;element name="PeriodicPaymentProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreatePeriodicPaymentProfileResponseType", propOrder = {
    "accountNumber",
    "achProfileNumber",
    "periodicPaymentProfileNumber"
})
public class CreatePeriodicPaymentProfileResponseType {

    @XmlElement(name = "AccountNumber", required = true)
    protected String accountNumber;
    @XmlElement(name = "ACHProfileNumber")
    protected String achProfileNumber;
    @XmlElement(name = "PeriodicPaymentProfileNumber", required = true)
    protected String periodicPaymentProfileNumber;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the achProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACHProfileNumber() {
        return achProfileNumber;
    }

    /**
     * Sets the value of the achProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACHProfileNumber(String value) {
        this.achProfileNumber = value;
    }

    /**
     * Gets the value of the periodicPaymentProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicPaymentProfileNumber() {
        return periodicPaymentProfileNumber;
    }

    /**
     * Sets the value of the periodicPaymentProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicPaymentProfileNumber(String value) {
        this.periodicPaymentProfileNumber = value;
    }

}
