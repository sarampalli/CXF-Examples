
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeletePeriodicDraftingProfileRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeletePeriodicDraftingProfileRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}RJAccountNumberType"/>
 *         &lt;element name="ACHProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType" minOccurs="0"/>
 *         &lt;element name="PeriodicDraftingProfileNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ProfileNumberType"/>
 *         &lt;element name="UserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeletePeriodicDraftingProfileRequestType", propOrder = {
    "accountNumber",
    "achProfileNumber",
    "periodicDraftingProfileNumber",
    "userName"
})
public class DeletePeriodicDraftingProfileRequestType {

    @XmlElement(name = "AccountNumber", required = true)
    protected String accountNumber;
    @XmlElement(name = "ACHProfileNumber")
    protected String achProfileNumber;
    @XmlElement(name = "PeriodicDraftingProfileNumber", required = true)
    protected String periodicDraftingProfileNumber;
    @XmlElement(name = "UserName", required = true)
    protected String userName;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the achProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACHProfileNumber() {
        return achProfileNumber;
    }

    /**
     * Sets the value of the achProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACHProfileNumber(String value) {
        this.achProfileNumber = value;
    }

    /**
     * Gets the value of the periodicDraftingProfileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicDraftingProfileNumber() {
        return periodicDraftingProfileNumber;
    }

    /**
     * Sets the value of the periodicDraftingProfileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicDraftingProfileNumber(String value) {
        this.periodicDraftingProfileNumber = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

}
