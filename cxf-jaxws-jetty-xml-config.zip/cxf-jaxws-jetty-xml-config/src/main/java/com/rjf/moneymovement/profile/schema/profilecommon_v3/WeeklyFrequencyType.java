
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WeeklyFrequencyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WeeklyFrequencyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PrimaryPaymentDay" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DayOfWeekType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WeeklyFrequencyType", propOrder = {
    "primaryPaymentDay"
})
public class WeeklyFrequencyType {

    @XmlElement(name = "PrimaryPaymentDay", required = true)
    protected DayOfWeekType primaryPaymentDay;

    /**
     * Gets the value of the primaryPaymentDay property.
     * 
     * @return
     *     possible object is
     *     {@link DayOfWeekType }
     *     
     */
    public DayOfWeekType getPrimaryPaymentDay() {
        return primaryPaymentDay;
    }

    /**
     * Sets the value of the primaryPaymentDay property.
     * 
     * @param value
     *     allowed object is
     *     {@link DayOfWeekType }
     *     
     */
    public void setPrimaryPaymentDay(DayOfWeekType value) {
        this.primaryPaymentDay = value;
    }

}
