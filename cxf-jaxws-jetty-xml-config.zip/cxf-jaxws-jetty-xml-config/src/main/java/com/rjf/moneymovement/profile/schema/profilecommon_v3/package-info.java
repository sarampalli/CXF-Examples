@javax.xml.bind.annotation.XmlSchema(namespace = "http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.rjf.moneymovement.profile.schema.profilecommon_v3;
