
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FinancialInstitutionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialInstitutionType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}FinancialInstitutionBaseType">
 *       &lt;sequence>
 *         &lt;element name="AccountName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ABANumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ABANumberType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialInstitutionType", propOrder = {
    "accountName",
    "abaNumber"
})
public class FinancialInstitutionType
    extends FinancialInstitutionBaseType
{

    @XmlElement(name = "AccountName", required = true)
    protected String accountName;
    @XmlElement(name = "ABANumber")
    protected String abaNumber;

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountName(String value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the abaNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getABANumber() {
        return abaNumber;
    }

    /**
     * Sets the value of the abaNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setABANumber(String value) {
        this.abaNumber = value;
    }

}
