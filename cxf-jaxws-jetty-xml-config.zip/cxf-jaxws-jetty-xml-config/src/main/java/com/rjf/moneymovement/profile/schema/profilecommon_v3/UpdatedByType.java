
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Added to v2
 * 
 * <p>Java class for UpdatedByType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdatedByType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UpdatedByTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="PreviousUpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreviousUpdatedByTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdatedByType", propOrder = {
    "updatedBy",
    "updatedByTimeStamp",
    "previousUpdatedBy",
    "previousUpdatedByTimeStamp"
})
public class UpdatedByType {

    @XmlElement(name = "UpdatedBy")
    protected String updatedBy;
    @XmlElement(name = "UpdatedByTimeStamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar updatedByTimeStamp;
    @XmlElement(name = "PreviousUpdatedBy")
    protected String previousUpdatedBy;
    @XmlElement(name = "PreviousUpdatedByTimeStamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar previousUpdatedByTimeStamp;

    /**
     * Gets the value of the updatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the value of the updatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedBy(String value) {
        this.updatedBy = value;
    }

    /**
     * Gets the value of the updatedByTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getUpdatedByTimeStamp() {
        return updatedByTimeStamp;
    }

    /**
     * Sets the value of the updatedByTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setUpdatedByTimeStamp(XMLGregorianCalendar value) {
        this.updatedByTimeStamp = value;
    }

    /**
     * Gets the value of the previousUpdatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreviousUpdatedBy() {
        return previousUpdatedBy;
    }

    /**
     * Sets the value of the previousUpdatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreviousUpdatedBy(String value) {
        this.previousUpdatedBy = value;
    }

    /**
     * Gets the value of the previousUpdatedByTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPreviousUpdatedByTimeStamp() {
        return previousUpdatedByTimeStamp;
    }

    /**
     * Sets the value of the previousUpdatedByTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPreviousUpdatedByTimeStamp(XMLGregorianCalendar value) {
        this.previousUpdatedByTimeStamp = value;
    }

}
