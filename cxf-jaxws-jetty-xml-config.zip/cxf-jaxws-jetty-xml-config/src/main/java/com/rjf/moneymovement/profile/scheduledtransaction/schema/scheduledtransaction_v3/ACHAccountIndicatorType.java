
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ACHAccountIndicatorType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ACHAccountIndicatorType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SSPD"/>
 *     &lt;enumeration value="INAC"/>
 *     &lt;enumeration value="ACTV"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ACHAccountIndicatorType")
@XmlEnum
public enum ACHAccountIndicatorType {

    SSPD,
    INAC,
    ACTV;

    public String value() {
        return name();
    }

    public static ACHAccountIndicatorType fromValue(String v) {
        return valueOf(v);
    }

}
