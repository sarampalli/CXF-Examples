
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3.CreatePeriodicPaymentProfileRequestType;
import com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3.UpdatePeriodicPaymentProfileRequestType;
import com.rjf.moneymovement.profile.schema.profilecommon_v3.BrokerageAccountTypeEnum;


/**
 * <p>Java class for PeriodicPaymentProfileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicPaymentProfileType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}PeriodicProfileBaseType">
 *       &lt;sequence>
 *         &lt;element name="BrokerageAccountType" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}BrokerageAccountTypeEnum"/>
 *         &lt;element name="ReleaseStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FANumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}BranchNumberType" minOccurs="0"/>
 *         &lt;element name="GrossAmount" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MoneyAmountType" minOccurs="0"/>
 *         &lt;element name="NetAmount" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MoneyAmountType" minOccurs="0"/>
 *         &lt;element name="FederalWithholdingPercentRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StateWithholdingPercentRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PeriodicPaymentFee" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MoneyAmountType" minOccurs="0"/>
 *         &lt;element name="TransactionCodeIRA" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="AutoRMDFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ACHAccountIndicator" type="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}ACHAccountIndicatorType" minOccurs="0"/>
 *         &lt;element name="SpecialInstructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OneTimeProfileFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="OverrideTrailerIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ThirdPartyIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="TransferToAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransferToAccountTrailer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CheckSendToAddress" type="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}PaymentAddressType" minOccurs="0"/>
 *         &lt;element name="CheckPrintLocation" type="{http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3}CheckPrintLocationEnum" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicPaymentProfileType", propOrder = {
    "brokerageAccountType",
    "releaseStatus",
    "faNumber",
    "branchNumber",
    "grossAmount",
    "netAmount",
    "federalWithholdingPercentRate",
    "stateWithholdingPercentRate",
    "periodicPaymentFee",
    "transactionCodeIRA",
    "autoRMDFlag",
    "achAccountIndicator",
    "specialInstructions",
    "oneTimeProfileFlag",
    "overrideTrailerIndicator",
    "thirdPartyIndicator",
    "transferToAccount",
    "transferToAccountTrailer",
    "checkSendToAddress",
    "checkPrintLocation"
})
@XmlSeeAlso({
    CreatePeriodicPaymentProfileRequestType.class,
    UpdatePeriodicPaymentProfileRequestType.class
})
public class PeriodicPaymentProfileType
    extends PeriodicProfileBaseType
{

    @XmlElement(name = "BrokerageAccountType", required = true)
    protected BrokerageAccountTypeEnum brokerageAccountType;
    @XmlElement(name = "ReleaseStatus")
    protected String releaseStatus;
    @XmlElement(name = "FANumber")
    protected String faNumber;
    @XmlElement(name = "BranchNumber")
    protected String branchNumber;
    @XmlElement(name = "GrossAmount")
    protected BigDecimal grossAmount;
    @XmlElement(name = "NetAmount")
    protected BigDecimal netAmount;
    @XmlElement(name = "FederalWithholdingPercentRate")
    protected String federalWithholdingPercentRate;
    @XmlElement(name = "StateWithholdingPercentRate")
    protected String stateWithholdingPercentRate;
    @XmlElement(name = "PeriodicPaymentFee")
    protected BigDecimal periodicPaymentFee;
    @XmlElement(name = "TransactionCodeIRA")
    protected Integer transactionCodeIRA;
    @XmlElement(name = "AutoRMDFlag")
    protected Boolean autoRMDFlag;
    @XmlElement(name = "ACHAccountIndicator")
    protected ACHAccountIndicatorType achAccountIndicator;
    @XmlElement(name = "SpecialInstructions")
    protected String specialInstructions;
    @XmlElement(name = "OneTimeProfileFlag")
    protected Boolean oneTimeProfileFlag;
    @XmlElement(name = "OverrideTrailerIndicator")
    protected Boolean overrideTrailerIndicator;
    @XmlElement(name = "ThirdPartyIndicator")
    protected Boolean thirdPartyIndicator;
    @XmlElement(name = "TransferToAccount")
    protected String transferToAccount;
    @XmlElement(name = "TransferToAccountTrailer")
    protected String transferToAccountTrailer;
    @XmlElement(name = "CheckSendToAddress")
    protected PaymentAddressType checkSendToAddress;
    @XmlElement(name = "CheckPrintLocation")
    protected CheckPrintLocationEnum checkPrintLocation;

    /**
     * Gets the value of the brokerageAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link BrokerageAccountTypeEnum }
     *     
     */
    public BrokerageAccountTypeEnum getBrokerageAccountType() {
        return brokerageAccountType;
    }

    /**
     * Sets the value of the brokerageAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BrokerageAccountTypeEnum }
     *     
     */
    public void setBrokerageAccountType(BrokerageAccountTypeEnum value) {
        this.brokerageAccountType = value;
    }

    /**
     * Gets the value of the releaseStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReleaseStatus() {
        return releaseStatus;
    }

    /**
     * Sets the value of the releaseStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReleaseStatus(String value) {
        this.releaseStatus = value;
    }

    /**
     * Gets the value of the faNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFANumber() {
        return faNumber;
    }

    /**
     * Sets the value of the faNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFANumber(String value) {
        this.faNumber = value;
    }

    /**
     * Gets the value of the branchNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchNumber() {
        return branchNumber;
    }

    /**
     * Sets the value of the branchNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchNumber(String value) {
        this.branchNumber = value;
    }

    /**
     * Gets the value of the grossAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGrossAmount() {
        return grossAmount;
    }

    /**
     * Sets the value of the grossAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGrossAmount(BigDecimal value) {
        this.grossAmount = value;
    }

    /**
     * Gets the value of the netAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetAmount() {
        return netAmount;
    }

    /**
     * Sets the value of the netAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetAmount(BigDecimal value) {
        this.netAmount = value;
    }

    /**
     * Gets the value of the federalWithholdingPercentRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFederalWithholdingPercentRate() {
        return federalWithholdingPercentRate;
    }

    /**
     * Sets the value of the federalWithholdingPercentRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFederalWithholdingPercentRate(String value) {
        this.federalWithholdingPercentRate = value;
    }

    /**
     * Gets the value of the stateWithholdingPercentRate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStateWithholdingPercentRate() {
        return stateWithholdingPercentRate;
    }

    /**
     * Sets the value of the stateWithholdingPercentRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStateWithholdingPercentRate(String value) {
        this.stateWithholdingPercentRate = value;
    }

    /**
     * Gets the value of the periodicPaymentFee property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPeriodicPaymentFee() {
        return periodicPaymentFee;
    }

    /**
     * Sets the value of the periodicPaymentFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPeriodicPaymentFee(BigDecimal value) {
        this.periodicPaymentFee = value;
    }

    /**
     * Gets the value of the transactionCodeIRA property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransactionCodeIRA() {
        return transactionCodeIRA;
    }

    /**
     * Sets the value of the transactionCodeIRA property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransactionCodeIRA(Integer value) {
        this.transactionCodeIRA = value;
    }

    /**
     * Gets the value of the autoRMDFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAutoRMDFlag() {
        return autoRMDFlag;
    }

    /**
     * Sets the value of the autoRMDFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAutoRMDFlag(Boolean value) {
        this.autoRMDFlag = value;
    }

    /**
     * Gets the value of the achAccountIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link ACHAccountIndicatorType }
     *     
     */
    public ACHAccountIndicatorType getACHAccountIndicator() {
        return achAccountIndicator;
    }

    /**
     * Sets the value of the achAccountIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link ACHAccountIndicatorType }
     *     
     */
    public void setACHAccountIndicator(ACHAccountIndicatorType value) {
        this.achAccountIndicator = value;
    }

    /**
     * Gets the value of the specialInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialInstructions() {
        return specialInstructions;
    }

    /**
     * Sets the value of the specialInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialInstructions(String value) {
        this.specialInstructions = value;
    }

    /**
     * Gets the value of the oneTimeProfileFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOneTimeProfileFlag() {
        return oneTimeProfileFlag;
    }

    /**
     * Sets the value of the oneTimeProfileFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOneTimeProfileFlag(Boolean value) {
        this.oneTimeProfileFlag = value;
    }

    /**
     * Gets the value of the overrideTrailerIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOverrideTrailerIndicator() {
        return overrideTrailerIndicator;
    }

    /**
     * Sets the value of the overrideTrailerIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOverrideTrailerIndicator(Boolean value) {
        this.overrideTrailerIndicator = value;
    }

    /**
     * Gets the value of the thirdPartyIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isThirdPartyIndicator() {
        return thirdPartyIndicator;
    }

    /**
     * Sets the value of the thirdPartyIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setThirdPartyIndicator(Boolean value) {
        this.thirdPartyIndicator = value;
    }

    /**
     * Gets the value of the transferToAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferToAccount() {
        return transferToAccount;
    }

    /**
     * Sets the value of the transferToAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferToAccount(String value) {
        this.transferToAccount = value;
    }

    /**
     * Gets the value of the transferToAccountTrailer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferToAccountTrailer() {
        return transferToAccountTrailer;
    }

    /**
     * Sets the value of the transferToAccountTrailer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferToAccountTrailer(String value) {
        this.transferToAccountTrailer = value;
    }

    /**
     * Gets the value of the checkSendToAddress property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentAddressType }
     *     
     */
    public PaymentAddressType getCheckSendToAddress() {
        return checkSendToAddress;
    }

    /**
     * Sets the value of the checkSendToAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentAddressType }
     *     
     */
    public void setCheckSendToAddress(PaymentAddressType value) {
        this.checkSendToAddress = value;
    }

    /**
     * Gets the value of the checkPrintLocation property.
     * 
     * @return
     *     possible object is
     *     {@link CheckPrintLocationEnum }
     *     
     */
    public CheckPrintLocationEnum getCheckPrintLocation() {
        return checkPrintLocation;
    }

    /**
     * Sets the value of the checkPrintLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link CheckPrintLocationEnum }
     *     
     */
    public void setCheckPrintLocation(CheckPrintLocationEnum value) {
        this.checkPrintLocation = value;
    }

}
