
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CheckPrintLocationEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CheckPrintLocationEnum">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HOMEO"/>
 *     &lt;enumeration value="DETRT"/>
 *     &lt;enumeration value="MPHIS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CheckPrintLocationEnum")
@XmlEnum
public enum CheckPrintLocationEnum {

    HOMEO,
    DETRT,
    MPHIS;

    public String value() {
        return name();
    }

    public static CheckPrintLocationEnum fromValue(String v) {
        return valueOf(v);
    }

}
