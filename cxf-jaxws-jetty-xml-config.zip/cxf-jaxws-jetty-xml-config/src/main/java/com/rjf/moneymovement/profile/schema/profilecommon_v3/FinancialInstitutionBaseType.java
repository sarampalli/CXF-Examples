
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FinancialInstitutionBaseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialInstitutionBaseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNumber" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}ExternalAccountNumberType"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DemandDepositType" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DemandDepositTypeEnum"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialInstitutionBaseType", propOrder = {
    "accountNumber",
    "name",
    "demandDepositType"
})
@XmlSeeAlso({
    FinancialInstitutionType.class
})
public class FinancialInstitutionBaseType {

    @XmlElement(name = "AccountNumber", required = true)
    protected String accountNumber;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "DemandDepositType", required = true)
    protected DemandDepositTypeEnum demandDepositType;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the demandDepositType property.
     * 
     * @return
     *     possible object is
     *     {@link DemandDepositTypeEnum }
     *     
     */
    public DemandDepositTypeEnum getDemandDepositType() {
        return demandDepositType;
    }

    /**
     * Sets the value of the demandDepositType property.
     * 
     * @param value
     *     allowed object is
     *     {@link DemandDepositTypeEnum }
     *     
     */
    public void setDemandDepositType(DemandDepositTypeEnum value) {
        this.demandDepositType = value;
    }

}
