
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnnualFrequencyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AnnualFrequencyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PaymentStartMonth" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MonthNumberType"/>
 *         &lt;element name="PrimaryPaymentDay" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DayOfMonthType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnnualFrequencyType", propOrder = {
    "paymentStartMonth",
    "primaryPaymentDay"
})
public class AnnualFrequencyType {

    @XmlElement(name = "PaymentStartMonth")
    protected int paymentStartMonth;
    @XmlElement(name = "PrimaryPaymentDay")
    protected int primaryPaymentDay;

    /**
     * Gets the value of the paymentStartMonth property.
     * 
     */
    public int getPaymentStartMonth() {
        return paymentStartMonth;
    }

    /**
     * Sets the value of the paymentStartMonth property.
     * 
     */
    public void setPaymentStartMonth(int value) {
        this.paymentStartMonth = value;
    }

    /**
     * Gets the value of the primaryPaymentDay property.
     * 
     */
    public int getPrimaryPaymentDay() {
        return primaryPaymentDay;
    }

    /**
     * Sets the value of the primaryPaymentDay property.
     * 
     */
    public void setPrimaryPaymentDay(int value) {
        this.primaryPaymentDay = value;
    }

}
