@javax.xml.bind.annotation.XmlSchema(namespace = "http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransactionServiceMessages-v3", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3;
