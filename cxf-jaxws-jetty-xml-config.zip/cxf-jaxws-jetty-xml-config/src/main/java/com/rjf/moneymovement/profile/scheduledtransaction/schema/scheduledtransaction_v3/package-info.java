@javax.xml.bind.annotation.XmlSchema(namespace = "http://moneymovement.rjf.com/Profile/ScheduledTransaction/Schema/ScheduledTransaction-v3", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransaction_v3;
