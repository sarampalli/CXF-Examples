
package com.rjf.moneymovement.profile.scheduledtransaction.schema.scheduledtransactionservicemessages_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.rjf.moneymovement.profile.schema.profilecommon_v3.DeleteStatusType;


/**
 * <p>Java class for DeletePeriodicPaymentProfileResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeletePeriodicPaymentProfileResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DeleteStatus" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DeleteStatusType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeletePeriodicPaymentProfileResponseType", propOrder = {
    "deleteStatus"
})
public class DeletePeriodicPaymentProfileResponseType {

    @XmlElement(name = "DeleteStatus", required = true)
    protected DeleteStatusType deleteStatus;

    /**
     * Gets the value of the deleteStatus property.
     * 
     * @return
     *     possible object is
     *     {@link DeleteStatusType }
     *     
     */
    public DeleteStatusType getDeleteStatus() {
        return deleteStatus;
    }

    /**
     * Sets the value of the deleteStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeleteStatusType }
     *     
     */
    public void setDeleteStatus(DeleteStatusType value) {
        this.deleteStatus = value;
    }

}
