
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentFrequencyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentFrequencyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="Daily" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Weekly" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}WeeklyFrequencyType"/>
 *         &lt;element name="Monthly" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}MonthlyFrequencyType"/>
 *         &lt;element name="SemiMonthly" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}SemiMonthlyFrequencyType"/>
 *         &lt;element name="Quarterly" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}QuarterlyFrequencyType"/>
 *         &lt;element name="SemiAnnual" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}SemiAnnualFrequencyType"/>
 *         &lt;element name="Annual" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}AnnualFrequencyType"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentFrequencyType", propOrder = {
    "daily",
    "weekly",
    "monthly",
    "semiMonthly",
    "quarterly",
    "semiAnnual",
    "annual"
})
public class PaymentFrequencyType {

    @XmlElement(name = "Daily")
    protected String daily;
    @XmlElement(name = "Weekly")
    protected WeeklyFrequencyType weekly;
    @XmlElement(name = "Monthly")
    protected MonthlyFrequencyType monthly;
    @XmlElement(name = "SemiMonthly")
    protected SemiMonthlyFrequencyType semiMonthly;
    @XmlElement(name = "Quarterly")
    protected QuarterlyFrequencyType quarterly;
    @XmlElement(name = "SemiAnnual")
    protected SemiAnnualFrequencyType semiAnnual;
    @XmlElement(name = "Annual")
    protected AnnualFrequencyType annual;

    /**
     * Gets the value of the daily property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDaily() {
        return daily;
    }

    /**
     * Sets the value of the daily property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDaily(String value) {
        this.daily = value;
    }

    /**
     * Gets the value of the weekly property.
     * 
     * @return
     *     possible object is
     *     {@link WeeklyFrequencyType }
     *     
     */
    public WeeklyFrequencyType getWeekly() {
        return weekly;
    }

    /**
     * Sets the value of the weekly property.
     * 
     * @param value
     *     allowed object is
     *     {@link WeeklyFrequencyType }
     *     
     */
    public void setWeekly(WeeklyFrequencyType value) {
        this.weekly = value;
    }

    /**
     * Gets the value of the monthly property.
     * 
     * @return
     *     possible object is
     *     {@link MonthlyFrequencyType }
     *     
     */
    public MonthlyFrequencyType getMonthly() {
        return monthly;
    }

    /**
     * Sets the value of the monthly property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonthlyFrequencyType }
     *     
     */
    public void setMonthly(MonthlyFrequencyType value) {
        this.monthly = value;
    }

    /**
     * Gets the value of the semiMonthly property.
     * 
     * @return
     *     possible object is
     *     {@link SemiMonthlyFrequencyType }
     *     
     */
    public SemiMonthlyFrequencyType getSemiMonthly() {
        return semiMonthly;
    }

    /**
     * Sets the value of the semiMonthly property.
     * 
     * @param value
     *     allowed object is
     *     {@link SemiMonthlyFrequencyType }
     *     
     */
    public void setSemiMonthly(SemiMonthlyFrequencyType value) {
        this.semiMonthly = value;
    }

    /**
     * Gets the value of the quarterly property.
     * 
     * @return
     *     possible object is
     *     {@link QuarterlyFrequencyType }
     *     
     */
    public QuarterlyFrequencyType getQuarterly() {
        return quarterly;
    }

    /**
     * Sets the value of the quarterly property.
     * 
     * @param value
     *     allowed object is
     *     {@link QuarterlyFrequencyType }
     *     
     */
    public void setQuarterly(QuarterlyFrequencyType value) {
        this.quarterly = value;
    }

    /**
     * Gets the value of the semiAnnual property.
     * 
     * @return
     *     possible object is
     *     {@link SemiAnnualFrequencyType }
     *     
     */
    public SemiAnnualFrequencyType getSemiAnnual() {
        return semiAnnual;
    }

    /**
     * Sets the value of the semiAnnual property.
     * 
     * @param value
     *     allowed object is
     *     {@link SemiAnnualFrequencyType }
     *     
     */
    public void setSemiAnnual(SemiAnnualFrequencyType value) {
        this.semiAnnual = value;
    }

    /**
     * Gets the value of the annual property.
     * 
     * @return
     *     possible object is
     *     {@link AnnualFrequencyType }
     *     
     */
    public AnnualFrequencyType getAnnual() {
        return annual;
    }

    /**
     * Sets the value of the annual property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnnualFrequencyType }
     *     
     */
    public void setAnnual(AnnualFrequencyType value) {
        this.annual = value;
    }

}
