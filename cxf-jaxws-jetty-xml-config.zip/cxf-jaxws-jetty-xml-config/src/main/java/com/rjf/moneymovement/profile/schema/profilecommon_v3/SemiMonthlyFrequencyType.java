
package com.rjf.moneymovement.profile.schema.profilecommon_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SemiMonthlyFrequencyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SemiMonthlyFrequencyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PrimaryPaymentDay" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DayOfMonthType"/>
 *         &lt;element name="SecondaryPaymentDay" type="{http://moneymovement.rjf.com/Profile/Schema/ProfileCommon-v3}DayOfMonthType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SemiMonthlyFrequencyType", propOrder = {
    "primaryPaymentDay",
    "secondaryPaymentDay"
})
public class SemiMonthlyFrequencyType {

    @XmlElement(name = "PrimaryPaymentDay")
    protected int primaryPaymentDay;
    @XmlElement(name = "SecondaryPaymentDay")
    protected int secondaryPaymentDay;

    /**
     * Gets the value of the primaryPaymentDay property.
     * 
     */
    public int getPrimaryPaymentDay() {
        return primaryPaymentDay;
    }

    /**
     * Sets the value of the primaryPaymentDay property.
     * 
     */
    public void setPrimaryPaymentDay(int value) {
        this.primaryPaymentDay = value;
    }

    /**
     * Gets the value of the secondaryPaymentDay property.
     * 
     */
    public int getSecondaryPaymentDay() {
        return secondaryPaymentDay;
    }

    /**
     * Sets the value of the secondaryPaymentDay property.
     * 
     */
    public void setSecondaryPaymentDay(int value) {
        this.secondaryPaymentDay = value;
    }

}
