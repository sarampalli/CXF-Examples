# cxf-jaxws-jetty-xml-config

[![Quality Gate](https://sonarcloud.io/api/badges/gate?key=com.codenotfound:cxf-jaxws-jetty-xml-config)](https://sonarcloud.io/dashboard/index/com.codenotfound:cxf-jaxws-jetty-xml-config)

A detailed step-by-step tutorial on how to implement a CXF contract first Hello World web service.

[https://www.codenotfound.com/jaxws-cxf-contract-first-hello-world-webservice-tutorial.html](https://www.codenotfound.com/jaxws-cxf-contract-first-hello-world-webservice-tutorial.html)
